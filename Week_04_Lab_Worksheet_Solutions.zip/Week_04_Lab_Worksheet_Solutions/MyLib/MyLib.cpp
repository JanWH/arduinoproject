#include "Arduino.h"
#include "MyLib.h"
int MyLibClass::add(int a, int b) {
	int result = a + b;
	return result;
}
int MyLibClass::sub(int a, int b) {
	int result = a - b;
	return result;
}
// You have to use :: instead of a single : with class member functions
int MyLibClass::mult(int a, int b) {
	int result = a * b;
	return result;
}