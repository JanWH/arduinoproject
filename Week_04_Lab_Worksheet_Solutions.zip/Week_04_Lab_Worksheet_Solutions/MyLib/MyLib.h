#ifndef MyLib_h
#define MyLib_h
#include "Arduino.h"
class MyLibClass {
	public:
		int add(int, int);
		int sub(int, int);
		int mult(int, int);
};
#endif